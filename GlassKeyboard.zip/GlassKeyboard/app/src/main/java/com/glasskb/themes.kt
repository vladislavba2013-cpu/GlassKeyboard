panel = Color(0xFF000000),
) else Palette(
bg = Color(0xFFF4F4F4),
key = Color.White,
keyText = Color(0xFF111111),
special = Color(0xFFE5E5E5),
specialText = Color(0xFF525252),
enter = Color(0xFFD71921),
enterText = Color.White,
shiftOn = Color(0xFFD71921),
shiftOnText = Color.White,
highlight = Color(0xFFD4D4D4),
outline = Color(0xFF737373),
hint = Color(0xFF737373),
panel = Color(0xFFF4F4F4),
)
else -> paletteFor(context, "m3expressive", dark, false, emptyList())
}
if (amoled) {
p = p.copy(bg = Color.Black, panel = Color.Black)
}
return p
}
fun applyOverrides(base: Palette, s: KbSettings): Palette {
var p = base
if (s.accent != 0) {
val acc = Color(s.accent)
p = p.copy(enter = acc, shiftOn = acc, highlight = lerp(p.key, acc, 0.35f))
}
if (s.enterColor != 0) p = p.copy(enter = Color(s.enterColor))
if (s.shiftColor != 0) p = p.copy(shiftOn = Color(s.shiftColor))
if (s.highlightColor != 0) p = p.copy(highlight = Color(s.highlightColor))
return p
}
fun resolveFontFamily(s: KbSettings, info: ThemeInfo): FontFamily {
if (s.customFontPath.isNotEmpty()) {
val file = File(s.customFontPath)
if (file.exists()) {
runCatching {
val tf = Typeface.createFromFile(file)
return FontFamily(tf)
}
}
}
val kind = info.forcedFont ?: s.fontFamily
return when (kind) {
"serif" -> FontFamily.Serif
"mono", "pixel" -> FontFamily.Monospace
"system" -> FontFamily.Default
else -> FontFamily.SansSerif
}
}
fun toCustomTheme(id: String, name: String, info: ThemeInfo, p: Palette): CustomTheme = CustomTheme(
id = id,
name = name,
style = info.style.name,
shapeable = info.shapeable,
bg = p.bg.toArgb(),
key = p.key.toArgb(),
keyText = p.keyText.toArgb(),
special = p.special.toArgb(),
specialText = p.specialText.toArgb(),
enter = p.enter.toArgb(),
enterText = p.enterText.toArgb(),
shiftOn = p.shiftOn.toArgb(),
outline = p.outline.toArgb(),
hint = p.hint.toArgb(),
)
}
@Composable
fun rememberKbLook(s: KbSettings): KbLook {
val context = LocalContext.current
val systemDark = isSystemInDarkTheme()
val customList = SettingsStore.customThemes
return remember(s, systemDark, customList) {
val isDark = Themes.resolveDark(s.mode, systemDark)
val amoled = s.mode == "amoled"
val info = Themes.builtIn.firstOrNull { it.id == s.themeId }
?: customList.firstOrNull { it.id == s.themeId }?.toInfo()
?: Themes.builtIn.first()
val rawPalette = Themes.paletteFor(context, info.id, isDark, amoled, customList)
val palette = Themes.applyOverrides(rawPalette, s)
val glass = s.liquidGlass || info.style == KeyStyle.GLASS
val ff = Themes.resolveFontFamily(s, info)
val fw = FontWeight(s.fontWeight.coerceIn(300, 800))
KbLook(
p = palette,
info = info,
s = s,
isDark = isDark,
glass = glass,
fontFamily = ff,
fontWeight = fw,
)
}
}