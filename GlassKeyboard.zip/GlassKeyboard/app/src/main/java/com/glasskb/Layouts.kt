package com.glasskb

enum class KeyKind { CHAR, SHIFT, BACKSPACE, ENTER, SPACE, SYMBOLS, LANG, EMOJI, COMMA, PERIOD, CUSTOM, TOOLS }

data class KeyDef(
    val label: String,
    val kind: KeyKind = KeyKind.CHAR,
    val weight: Float = 1f,
    val hint: String? = null,
    val variants: List<String> = emptyList(),
)

object Layouts {
    val digits = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")

    private val ruRows = listOf(
        "йцукенгшщзхъ",
        "фывапролджэ",
        "ячсмитьбю",
    )
    private val enRows = listOf(
        "qwertyuiop",
        "asdfghjkl",
        "zxcvbnm",
    )

    private fun hintFor(row: Int, index: Int): String? =
        if (row == 0) digits.getOrNull((index + 1) % 10) else null

    val variants: Map<String, List<String>> = mapOf(
        "е" to listOf("ё"), "ь" to listOf("ъ"), "ъ" to listOf("ь"), "и" to listOf("й"),
        "a" to listOf("à", "á", "â", "ä", "æ", "ã", "å", "ā"),
        "e" to listOf("è", "é", "ê", "ë", "ē", "ė", "ę"),
        "i" to listOf("ì", "í", "î", "ï", "ī", "į"),
        "o" to listOf("ò", "ó", "ô", "ö", "õ", "ø", "œ", "ō"),
        "u" to listOf("ù", "ú", "û", "ü", "ū"),
        "c" to listOf("ç", "ć", "č"), "n" to listOf("ñ", "ń"),
        "s" to listOf("ß", "ś", "š"), "z" to listOf("ž", "ź", "ż"),
        "y" to listOf("ý", "ÿ"), "l" to listOf("ł"),
    )

    fun letterRows(lang: String): List<List<KeyDef>> {
        val src = if (lang == "ru") ruRows else enRows
        return src.mapIndexed { r, row ->
            row.mapIndexed { i, ch ->
                val s = ch.toString()
                KeyDef(s, KeyKind.CHAR, 1f, hintFor(r, i), variants[s].orEmpty())
            }
        }
    }

    val symbolsPage1 = listOf(
        listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"),
        listOf("@", "#", "$", "_", "&", "-", "+", "(", ")", "/"),
        listOf("*", "\"", "'", ":", ";", "!", "?"),
    )
    val symbolsPage2 = listOf(
        listOf("~", "`", "|", "•", "√", "π", "÷", "×", "¶", "Δ"),
        listOf("£", "¢", "€", "¥", "^", "°", "=", "{", "}", "\\"),
        listOf("%", "©", "®", "™", "✓", "[", "]"),
    )

    val numpadRows = listOf(
        listOf("1", "2", "3", "-"),
        listOf("4", "5", "6", "+"),
        listOf("7", "8", "9", ","),
        listOf("*", "0", "#", "⌫"),
    )

    fun gboardLongPress(char: String, row: Int, index: Int): String? =
        if (row == 0) digits.getOrNull((index + 1) % 10) else null

    val bottomRowIds = listOf("sym", "lang", "emoji", "left", "space", "right", "enter")

    fun bottomRowTitle(id: String) = when (id) {
        "sym" -> "?123"
        "lang" -> "Язык"
        "emoji" -> "Эмодзи"
        "left" -> "Лево от пробела"
        "space" -> "Пробел"
        "right" -> "Право от пробела"
        "enter" -> "Enter"
        else -> id
    }
}
