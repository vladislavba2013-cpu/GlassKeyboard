package com.glasskb

import android.Manifest
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.inputmethodservice.InputMethodService
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.InputType
import android.view.KeyEvent
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputMethodManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

enum class Panel { NONE, EMOJI, GIF, CLIP, EDIT }

/** Простейшие подсказки: небольшой встроенный словарь + слова, которые пользователь уже вводил. */
object Suggest {
    private val ru = listOf(
        "привет", "пока", "спасибо", "пожалуйста", "хорошо", "конечно", "сейчас", "сегодня", "завтра",
        "потом", "сколько", "почему", "когда", "где", "как", "что", "давай", "можно", "нужно", "ладно",
        "извини", "отлично", "здравствуйте", "добрый", "день", "вечер", "утро", "работа", "дома", "люблю",
    )
    private val en = listOf(
        "hello", "thanks", "please", "sorry", "okay", "great", "today", "tomorrow", "later", "because",
        "what", "when", "where", "which", "would", "could", "should", "there", "their", "about", "really",
        "good", "morning", "evening", "love", "think", "know", "going", "doing", "right",
    )
    private val learned = LinkedHashMap<String, Int>()

    fun learn(word: String) {
        val w = word.lowercase()
        if (w.length < 3) return
        learned[w] = (learned[w] ?: 0) + 1
        if (learned.size > 300) learned.remove(learned.keys.first())
    }

    fun forPrefix(prefix: String, lang: String): List<String> {
        if (prefix.isEmpty()) return emptyList()
        val p = prefix.lowercase()
        val fromLearned = learned.entries.filter { it.key.startsWith(p) && it.key != p }
            .sortedByDescending { it.value }.map { it.key }
        val base = (if (lang == "ru") ru else en).filter { it.startsWith(p) && it != p }
        return (fromLearned + base).distinct().take(3)
    }
}

class KbController(private val service: InputMethodService) {
    var lang by mutableStateOf("ru")
    var shift by mutableIntStateOf(0)          // 0 выкл, 1 одна заглавная, 2 caps lock
    var page by mutableIntStateOf(0)           // 0 буквы, 1 ?123, 2 =\<
    var panel by mutableStateOf(Panel.NONE)
    var numericMode by mutableStateOf(false)
    var actionGlyph by mutableStateOf("↵")
    var suggestions by mutableStateOf<List<String>>(emptyList())
    var clipPreview by mutableStateOf<String?>(null)
    var langMenu by mutableStateOf(false)
    var toolsPinned by mutableStateOf(false)
    var selecting by mutableStateOf(false)
    /** Границы клавиатуры в координатах окна IME (для touchableRegion) и отступ её верха внутри input view. */
    val kbBounds = android.graphics.Rect()
    var kbTopInView = 0

    fun updateBounds(l: Int, t: Int, r: Int, b: Int) {
        if (kbBounds.left == l && kbBounds.top == t && kbBounds.right == r && kbBounds.bottom == b) return
        kbBounds.set(l, t, r, b)
        kbTopInView = t
        (service as? KeyboardService)?.refreshInsets()
    }

