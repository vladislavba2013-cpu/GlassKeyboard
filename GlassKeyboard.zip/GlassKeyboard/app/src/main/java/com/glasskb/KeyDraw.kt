package com.glasskb

import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Shader
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.RenderEffect
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import kotlin.random.Random

enum class Role { NORMAL, SPECIAL, ENTER, SHIFT_ON }

fun effectiveStyle(look: KbLook): KeyStyle =
    if (look.glass) KeyStyle.GLASS else look.info.style

fun roleFill(look: KbLook, role: Role): Color = when (role) {
    Role.NORMAL -> look.p.key
    Role.SPECIAL -> look.p.special
    Role.ENTER -> look.p.enter
    Role.SHIFT_ON -> look.p.shiftOn
}

fun roleText(look: KbLook, role: Role): Color {
    val p = look.p
    return when (role) {
        Role.NORMAL -> if (effectiveStyle(look) == KeyStyle.NEON) p.outline else p.keyText
        Role.SPECIAL -> p.specialText
        Role.ENTER -> p.enterText
        Role.SHIFT_ON -> p.shiftOnText
    }
}

private fun neonAccent(look: KbLook, role: Role): Color = when (role) {
    Role.NORMAL -> look.p.outline
    Role.SPECIAL -> look.p.specialText
    Role.ENTER -> look.p.enterText
    Role.SHIFT_ON -> look.p.shiftOnText
}

fun outlineToPath(o: Outline): Path = when (o) {
    is Outline.Generic -> o.path
    is Outline.Rounded -> Path().apply { addRoundRect(o.roundRect) }
    is Outline.Rectangle -> Path().apply { addRect(o.rect) }
}

@RequiresApi(Build.VERSION_CODES.S)
fun glassBlurEffect(radiusPx: Float = 26f): RenderEffect {
    val blur = android.graphics.RenderEffect.createBlurEffect(radiusPx, radiusPx, Shader.TileMode.CLAMP)
    val cm = ColorMatrix().apply { setSaturation(1.35f) }
    val sat = android.graphics.RenderEffect.createColorFilterEffect(ColorMatrixColorFilter(cm))
    return android.graphics.RenderEffect.createChainEffect(sat, blur).asComposeRenderEffect()
}

fun DrawScope.drawKeyBody(look: KbLook, role: Role, w: Float, h: Float, t: Float, seed: Int) {
    val p = look.p
    val style = effectiveStyle(look)
    val base = roleFill(look, role)
    val size = Size(w, h)
    val path = outlineToPath(keyShape(look, t).createOutline(size, LayoutDirection.Ltr, this))
    val pressedFill = lerp(base, p.highlight, t * 0.30f)
    val outlineW = 1.dp.toPx()

    when (style) {
        KeyStyle.FLAT -> {
            drawPath(path, pressedFill)
            if (look.s.keyOutline) drawPath(path, p.outline, style = Stroke(outlineW))
        }

        KeyStyle.GLASS -> {
            val tinted = if (look.info.style == KeyStyle.GLASS) base else base.copy(alpha = base.alpha * 0.45f)
            val a = (tinted.alpha + t * 0.15f).coerceAtMost(1f)
            drawPath(
                path,
                Brush.verticalGradient(
                    colors = listOf(
                        Color.White.copy(alpha = (0.34f + t * 0.14f).coerceAtMost(0.65f)),
                        tinted.copy(alpha = a),
                        tinted.copy(alpha = (a * 0.72f).coerceAtLeast(0.18f)),
                    ),
                    startY = 0f,
                    endY = h,
                ),
            )
            // Внутренний блик стекла сверху
            clipPath(path) {
                drawRect(
                    brush = Brush.verticalGradient(
                        listOf(Color.White.copy(alpha = 0.28f), Color.Transparent),
                        startY = 0f,
                        endY = h * 0.42f,
                    ),
                    size = Size(w, h * 0.42f),
                )
            }
            drawPath(
                path,
                Brush.verticalGradient(
                    listOf(Color.White.copy(alpha = 0.65f), p.outline.copy(alpha = 0.35f)),
                    startY = 0f,
                    endY = h,
                ),
                style = Stroke(1.2.dp.toPx()),
            )
        }

        KeyStyle.NEON -> {
            val accent = neonAccent(look, role)
            drawPath(path, pressedFill)
            // Внешнее свечение (glow)
            drawPath(path, accent.copy(alpha = 0.18f + t * 0.22f), style = Stroke(5.dp.toPx()))
            drawPath(path, accent.copy(alpha = 0.45f + t * 0.30f), style = Stroke(2.5.dp.toPx()))
            drawPath(path, accent, style = Stroke(1.2.dp.toPx()))
        }

        KeyStyle.NEU -> {
            val lightShadow = if (look.isDark) Color.White.copy(alpha = 0.08f) else Color.White.copy(alpha = 0.85f)
            val darkShadow = if (look.isDark) Color.Black.copy(alpha = 0.55f) else Color(0xFFA3B1C6).copy(alpha = 0.55f)
            val shift = (1f - t) * 2.5.dp.toPx()
            if (shift > 0.2f) {
                translate(-shift, -shift) { drawPath(path, lightShadow) }
                translate(shift, shift) { drawPath(path, darkShadow) }
            }
            drawPath(path, pressedFill)
            if (look.s.keyOutline) drawPath(path, p.outline.copy(alpha = 0.4f), style = Stroke(outlineW))
        }

        KeyStyle.PIXEL -> {
            val px = 3.dp.toPx()
            drawPath(path, pressedFill)
            clipPath(path) {
                val rng = Random(seed)
                repeat(10) {
                    val rx = (rng.nextInt((w / px).toInt().coerceAtLeast(1))) * px
                    val ry = (rng.nextInt((h / px).toInt().coerceAtLeast(1))) * px
                    val shade = if (rng.nextBoolean()) Color.White.copy(alpha = 0.08f) else Color.Black.copy(alpha = 0.12f)
                    drawRect(shade, topLeft = Offset(rx, ry), size = Size(px, px))
                }
                // Пиксельная фаска сверху/слева и тень снизу/справа
                drawRect(Color.White.copy(alpha = 0.28f), Offset.Zero, Size(w, px))
                drawRect(Color.White.copy(alpha = 0.20f), Offset.Zero, Size(px, h))
                drawRect(Color.Black.copy(alpha = 0.32f), Offset(0f, h - px), Size(w, px))
                drawRect(Color.Black.copy(alpha = 0.24f), Offset(w - px, 0f), Size(px, h))
            }
            drawPath(path, p.outline, style = Stroke(1.5.dp.toPx()))
        }

        KeyStyle.DOTTED -> {
            drawPath(path, pressedFill)
            val dash = PathEffect.dashPathEffect(floatArrayOf(3.dp.toPx(), 4.dp.toPx()), 0f)
            drawPath(path, p.outline, style = Stroke(width = 1.4.dp.toPx(), pathEffect = dash))
        }
    }
}
