package com.glasskb

import android.content.res.Configuration
import android.os.Build
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

private data class PopupState(
    val label: String,
    val variants: List<String>,
    val selectedVariantIdx: Int,
    val keyBounds: Rect,
)

@Composable
fun KeyboardRoot(controller: KbController) {
    val s = SettingsStore.settings
    val look = rememberKbLook(s)
    val config = LocalConfiguration.current
    val isLandscape = config.orientation == Configuration.ORIENTATION_LANDSCAPE
    val density = LocalDensity.current

    val effectiveWidthFraction = remember(s.widthPct, s.landscapePct, s.oneHand, s.oneHandWidthPct, isLandscape) {
        when {
            s.floating -> 0.88f
            s.oneHand != "off" && !isLandscape -> s.oneHandWidthPct / 100f
            isLandscape -> s.landscapePct / 100f
            else -> s.widthPct / 100f
        }.coerceIn(0.5f, 1f)
    }

    val containerAlign = when {
        s.floating -> Alignment.BottomCenter
        s.oneHand == "left" && !isLandscape -> Alignment.BottomStart
        s.oneHand == "right" && !isLandscape -> Alignment.BottomEnd
        else -> Alignment.BottomCenter
    }

    var rootBounds by remember { mutableStateOf(Rect.Zero) }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .onGloballyPositioned { rootBounds = it.boundsInRoot() },
        contentAlignment = containerAlign,
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = when (s.oneHand) {
                "left" -> Arrangement.Start
                "right" -> Arrangement.End
                else -> Arrangement.Center
            },
        ) {
            if (s.oneHand == "right" && !isLandscape && !s.floating) {
                OneHandSideStrip(controller, look)
            }

            val floatMod = if (s.floating) {
                Modifier
                    .offset { IntOffset(controller.floatOffsetX.roundToInt(), controller.floatOffsetY.roundToInt()) }
                    .clip(RoundedCornerShape(22.dp))
                    .border(1.dp, look.p.outline.copy(alpha = 0.45f), RoundedCornerShape(22.dp))
            } else Modifier

            val blurMod = if (look.glass && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                Modifier.graphicsLayer {
                    renderEffect = glassBlurEffect(22f)
                }
            } else Modifier

            Box(
                modifier = Modifier
                    .fillMaxWidth(effectiveWidthFraction)
                    .then(floatMod)
                    .onGloballyPositioned { coords ->
                        val b = coords.boundsInRoot()
                        controller.updateBounds(
                            b.left.roundToInt(),
                            b.top.roundToInt(),
                            b.right.roundToInt(),
                            b.bottom.roundToInt(),
                        )
                    },
            ) {
                // Фоновый слой (с размытием для Liquid Glass на Android 12+)
                Box(
                    modifier = Modifier
                        .matchParentSize()
                        .then(blurMod)
                        .background(look.p.bg),
                )

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .then(if (!s.floating) Modifier.navigationBarsPadding() else Modifier)
                        .padding(
                            start = s.sidePadDp.dp,
                            end = s.sidePadDp.dp,
                            top = if (s.floating) 4.dp else 6.dp,
                            bottom = s.bottomPadDp.dp,
                        ),
                ) {
                    if (s.floating) {
                        FloatingDragHandle(controller, look)
                    }

                    if (s.topBar) {
                        TopToolbar(controller, look)
                        Spacer(Modifier.height(4.dp))
                    }

                    if (controller.langMenu) {
                        LanguageQuickBar(controller, look)
                        Spacer(Modifier.height(4.dp))
                    }

                    val bodyHeight = remember(s.keyHeightDp, s.rowGapDp, s.numberRow) {
                        val rows = if (s.numberRow) 5 else 4
                        (s.keyHeightDp * rows + s.rowGapDp * (rows - 1)).dp
                    }

                    if (controller.panel != Panel.NONE) {
                        ActivePanelHost(controller, look, height = bodyHeight)
                    } else if (controller.numericMode) {
                        NumpadGrid(controller, look, totalHeight = bodyHeight)
                    } else {
                        KeyboardKeyGrid(controller, look, isSplit = s.splitLandscape && isLandscape, rootBounds = rootBounds)
                    }
                }
            }

            if (s.oneHand == "left" && !isLandscape && !s.floating) {
                OneHandSideStrip(controller, look)
            }
        }
    }
}

@Composable
private fun FloatingDragHandle(controller: KbController, look: KbLook) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(20.dp)
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    controller.floatOffsetX = (controller.floatOffsetX + dragAmount.x).coerceIn(-220f, 220f)
                    controller.floatOffsetY = (controller.floatOffsetY + dragAmount.y).coerceIn(-500f, 40f)
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        Box(
            modifier = Modifier
                .width(44.dp)
                .height(4.dp)
                .clip(CircleShape)
                .background(look.p.hint.copy(alpha = 0.5f)),
        )
    }
}

@Composable
private fun OneHandSideStrip(controller: KbController, look: KbLook) {
    Column(
        modifier = Modifier
            .padding(horizontal = 6.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(look.p.panel.copy(alpha = 0.9f))
            .padding(6.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(look.p.special)
                .clickable { SettingsStore.update { it.copy(oneHand = "off") } },
            contentAlignment = Alignment.Center,
        ) {
            Text("⤢", color = look.p.specialText, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(look.p.special)
                .clickable { controller.flipOneHand() },
            contentAlignment = Alignment.Center,
        ) {
            Text("⇄", color = look.p.specialText, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun TopToolbar(controller: KbController, look: KbLook) {
    val s = look.s
    val showSuggestions = s.suggestions && !controller.toolsPinned && controller.panel == Panel.NONE
    val scope = rememberCoroutineScope()

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(38.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(if (controller.toolsPinned) look.p.enter else look.p.special)
                .pointerInput(s.toolsLongPress) {
                    awaitEachGesture {
                        awaitFirstDown(requireUnconsumed = false)
                        var longFired = false
                        val job = scope.launch {
                            delay(420)
                            longFired = true
                            if (s.toolsLongPress == "edit") controller.togglePanel(Panel.EDIT)
                            else controller.toolsPinned = !controller.toolsPinned
                        }
                        waitForUpOrCancellation()
                        job.cancel()
                        if (!longFired) {
                            controller.toolsPinned = !controller.toolsPinned
                        }
                    }
                },
            contentAlignment = Alignment.Center,
        ) {
            GboardFourSquaresIcon(
                color = if (controller.toolsPinned) look.p.enterText else look.p.specialText,
                active = controller.toolsPinned,
            )
        }

        if (showSuggestions) {
            Row(
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(5.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                val itemsToShow = when {
                    controller.suggestions.isNotEmpty() -> controller.suggestions
                    !controller.clipPreview.isNullOrEmpty() -> listOf("\uD83D\uDCCB ${controller.clipPreview}")
                    else -> emptyList()
                }
                if (itemsToShow.isEmpty()) {
                    Spacer(Modifier.weight(1f))
                } else {
                    itemsToShow.take(3).forEach { item ->
                        val isClip = item.startsWith("\uD83D\uDCCB ")
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(32.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(look.p.key.copy(alpha = 0.85f))
                                .clickable {
                                    if (isClip) controller.onChar(item.removePrefix("\uD83D\uDCCB "))
                                    else controller.applySuggestion(item)
                                }
                                .padding(horizontal = 8.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                text = item,
                                color = look.p.keyText,
                                fontSize = 13.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                }
            }
        } else {
            Row(
                modifier = Modifier
                    .weight(1f)
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                ToolChip("\uD83D\uDE00", controller.panel == Panel.EMOJI, look) { controller.togglePanel(Panel.EMOJI) }
                ToolChip("GIF", controller.panel == Panel.GIF, look) { controller.togglePanel(Panel.GIF) }
                ToolChip("\uD83D\uDCCB", controller.panel == Panel.CLIP, look) { controller.togglePanel(Panel.CLIP) }
                if (s.editPanel) {
                    ToolChip("⇄", controller.panel == Panel.EDIT, look) { controller.togglePanel(Panel.EDIT) }
                }
                ToolChip("\uD83E\uDD1A", s.oneHand != "off", look) { controller.cycleOneHand() }
                ToolChip("⚙", false, look) { controller.openSettings() }
            }
        }

        if (s.micButton) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(if (controller.listening) look.p.enter else look.p.special)
                    .clickable { controller.startVoice() },
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = if (controller.listening) "●" else "\uD83C\uDFA4",
                    color = if (controller.listening) look.p.enterText else look.p.specialText,
                    fontSize = 15.sp,
                )
            }
        }
    }
}

@Composable
private fun GboardFourSquaresIcon(color: Color, active: Boolean) {
    Canvas(Modifier.size(16.dp)) {
        val gap = 2.dp.toPx()
        val cell = (size.width - gap) / 2f
        val r = 1.5.dp.toPx()
        drawRoundRect(color, Offset(0f, 0f), androidx.compose.ui.geometry.Size(cell, cell), androidx.compose.ui.geometry.CornerRadius(r))
        withTransform({
            rotate(if (active) 0f else 45f, pivot = Offset(cell + gap + cell / 2f, cell / 2f))
        }) {
            drawRoundRect(color, Offset(cell + gap, 0f), androidx.compose.ui.geometry.Size(cell, cell), androidx.compose.ui.geometry.CornerRadius(r))
        }
        drawRoundRect(color, Offset(0f, cell + gap), androidx.compose.ui.geometry.Size(cell, cell), androidx.compose.ui.geometry.CornerRadius(r))
        drawRoundRect(color, Offset(cell + gap, cell + gap), androidx.compose.ui.geometry.Size(cell, cell), androidx.compose.ui.geometry.CornerRadius(r))
    }
}

@Composable
private fun ToolChip(label: String, active: Boolean, look: KbLook, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .height(32.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(if (active) look.p.enter else look.p.special)
            .clickable { onClick() }
            .padding(horizontal = 10.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            color = if (active) look.p.enterText else look.p.specialText,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
        )
    }
}

@Composable
private fun LanguageQuickBar(controller: KbController, look: KbLook) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(look.p.special)
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        listOf("ru" to "Русский", "en" to "English").forEach { (code, title) ->
            val sel = controller.lang == code
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(32.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (sel) look.p.enter else Color.Transparent)
                    .clickable {
                        controller.lang = code
                        controller.langMenu = false
                    },
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = title,
                    color = if (sel) look.p.enterText else look.p.specialText,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                )
            }
        }
    }
}

@Composable
private fun NumpadGrid(controller: KbController, look: KbLook, totalHeight: Dp) {
    val gap = look.s.keyGapDp.dp
    val rowGap = look.s.rowGapDp.dp
    Column(
        modifier = Modifier.fillMaxWidth().height(totalHeight),
        verticalArrangement = Arrangement.spacedBy(rowGap),
    ) {
        Layouts.numpadRows.forEachIndexed { rIdx, row ->
            Row(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(gap),
            ) {
                row.forEachIndexed { cIdx, ch ->
                    val isBack = ch == "⌫"
                    val isOp = cIdx == 3
                    KeyCap(
                        def = KeyDef(ch, if (isBack) KeyKind.BACKSPACE else KeyKind.CHAR, 1f),
                        role = if (isOp) Role.SPECIAL else Role.NORMAL,
                        look = look,
                        seed = rIdx * 10 + cIdx,
                        modifier = Modifier.weight(1f),
                        onPress = { if (isBack) controller.onBackspace() else controller.onChar(ch) },
                    )
                }
            }
        }
    }
}

@Composable
private fun KeyboardKeyGrid(
    controller: KbController,
    look: KbLook,
    isSplit: Boolean,
    rootBounds: Rect,
) {
    val s = look.s
    val keyH = s.keyHeightDp.dp
    val gap = s.keyGapDp.dp
.graphicsLayer {
scaleX = scale
scaleY = scale
},
) {
drawKeyBody(look, role, size.width, size.height, t, seed)
}
if (look.s.hints && !def.hint.isNullOrEmpty()) {
Text(
text = def.hint,
color = look.p.hint,
fontSize = 10.sp,
fontFamily = look.fontFamily,
modifier = Modifier
.align(Alignment.TopEnd)
.padding(top = 3.dp, end = 6.dp),
)
}
Text(
text = def.label,
color = roleText(look, role),
fontSize = fontSizeSp,
fontFamily = look.fontFamily,
fontWeight = look.fontWeight,
textAlign = TextAlign.Center,
maxLines = 1,
)
}
}
internal var pendingVariantOverride: String? = null
private fun onVariantCommit(chosen: String, baseLabel: String, fallbackPress: () -> Unit) {
if (chosen == baseLabel) fallbackPress()
else {
pendingVariantOverride = chosen
fallbackPress()
}
}
@Composable
private fun KeyPopupOverlay(popup: PopupState, look: KbLook, rootBounds: Rect) {
val density = LocalDensity.current
val items = popup.variants.ifEmpty { listOf(popup.label) }
val itemW = 38.dp
val popupW = itemW * items.size + 8.dp
val popupH = 48.dp
val leftPx = (popup.keyBounds.center.x - rootBounds.left - with(density) { popupW.toPx() } / 2f)
.coerceIn(4f, (rootBounds.width - with(density) { popupW.toPx() } - 4f).coerceAtLeast(4f))
val topPx = (popup.keyBounds.top - rootBounds.top - with(density) { popupH.toPx() + 6.dp.toPx() })
.coerceAtLeast(0f)
Row(
modifier = Modifier
.offset { IntOffset(leftPx.roundToInt(), topPx.roundToInt()) }
.height(popupH)
.clip(RoundedCornerShape(14.dp))
.background(look.p.panel)
.border(1.dp, look.p.outline, RoundedCornerShape(14.dp))
.padding(horizontal = 4.dp),
verticalAlignment = Alignment.CenterVertically,
) {
items.forEachIndexed { idx, ch ->
val selected = popup.variants.isNotEmpty() && idx == popup.selectedVariantIdx
Box(
modifier = Modifier
.width(itemW)
.height(40.dp)
.clip(RoundedCornerShape(10.dp))
.background(if (selected) look.p.enter else Color.Transparent),
contentAlignment = Alignment.Center,
) {
Text(
text = ch,
color = if (selected) look.p.enterText else look.p.keyText,
fontSize = 22.sp,
fontFamily = look.fontFamily,
fontWeight = FontWeight.SemiBold,
)
}
}
}
}